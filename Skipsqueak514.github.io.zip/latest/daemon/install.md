# Daemon Installation

***

Currently, PortalNodes supports the use of [Pterodactyl Wings](https://github.com/pterodactyl/wings) as the server
management solution for nodes. Please follow Pterodactyl's guide for installation [here](https://pterodactyl.io/wings/1.0/installing.html).